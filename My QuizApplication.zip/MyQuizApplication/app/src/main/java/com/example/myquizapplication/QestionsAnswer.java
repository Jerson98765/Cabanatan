package com.example.myquizapplication;

public class QestionsAnswer {

    public static String question[] = {
            "Ano ka?",
            "Sino ka?",
            "Bakit ikaw?",


    };

    public static String choices [][] = {
            {"Tao", "Hayop", "Halimaw", "Multo"},
            {"Ewan", "diko knows", "wahtssss", "ewan ko"},
            {"wala lang", "ewan kolang", "ewan ko din", "idk"}

    };

    public static String correctAnswer[] ={

            "Tao",
            "wahtssss",
            "idk"
    };
}
